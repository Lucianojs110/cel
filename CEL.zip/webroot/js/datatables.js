$.extend( true, $.fn.dataTable.defaults, {
    "language": {
        "decimal": ",",
        "thousands": ".",
        "info": "Mostrando registros del _START_ al _END_ de un total de _TOTAL_ registros",
        "infoEmpty": "Mostrando registros del 0 al 0 de un total de 0 registros",
        "infoPostFix": "",
        "infoFiltered": "(filtrado de un total de _MAX_ registros)",
        "loadingRecords": "Cargando...",
        "lengthMenu": "Mostrar _MENU_ registros",
        "paginate": {
            "first": "Primero",
            "last": "Último",
            "next": "Siguiente",
            "previous": "Anterior"
        },
        "processing": "Procesando...",
        "search": "Buscar:",
        "searchPlaceholder": "Término de búsqueda",
        "zeroRecords": "No se encontraron resultados",
        "emptyTable": "Ningún dato disponible en esta tabla",
        "aria": {
            "sortAscending":  ": Activar para ordenar la columna de manera ascendente",
            "sortDescending": ": Activar para ordenar la columna de manera descendente"
        },
        //only works for built-in buttons, not for custom buttons
        "buttons": {
            "create": "Nuevo",
            "edit": "Cambiar",
            "remove": "Borrar",
            "copy": "Copiar",
            "csv": "Exportar CSV",
            "excel": "Exportar Excel",
            "pdf": "Exportar PDF",
            "print": "Imprimir",
            "colvis": "Visibilidad columnas",
            "collection": "Colección",
            "upload": "Seleccione fichero...."
        },
        "select": {
            "rows": {
                _: '%d filas seleccionadas',
                0: 'clic fila para seleccionar',
                1: 'una fila seleccionada'
            }
        }
    }           
} );       





$(document).ready(function () {

    $('#table3 thead th').each(function () {
        var title = $(this).text();  
        if (title!='Acciones'){ 
        $(this).html('<h1 style="width:100%; text-align:center; font-size:15px"><b>'+title+'</b></h1><input type="text"  style="width:100%" placeholder="Buscar..." />' ); }
        if (title=='Acciones'){ 
            $(this).html('<h1 style="width:80px; text-align:center; font-size:15px">'+title+'</h1>' ); }
        if (title=='Pickup'){ 
            $(this).html('<h1 style="width:80px; text-align:center; font-size:15px"><b>'+title+'</b></h1><input type="text"  style="width:100%" placeholder="Buscar..." />'  ); }
        
    });

    var table = $('#table3').DataTable(

       {"sScrollY": "350px",
       "sScrollX": "400px",} 
       
    );

    
    
    table.columns().every(function () {
        var table = this;
          
                $('input', this.header()).on('keyup change', function () {
                    if (table.search() !== this.value) {
                        table.search(this.value).draw();
                    }
            
         });
        
 });

});


$(document).ready(function() {
    $('#table2').DataTable( {
        "paging":   true,
        "lengthMenu": [ [10, 25, 50, -1], [10, 25, 50, "todos"] ],
        'iDisplayLength': 10,
        scrollX: true,
        "columnDefs": [
            { "width": "8%", "targets": 0 }
          ]
    } );
} );


$(document).ready(function () {

    $('#table thead th').each(function () {
        var title = $(this).text();  
        if (title!='Acciones'){ 
        $(this).html('<h1 style="width:100%; text-align:center; font-size:15px"><b>'+title+'</b></h1><input type="text"  style="width:100%" placeholder="Buscar..." />' ); }
        if (title=='Acciones'){ 
            $(this).html('<h1 style="width:100%; text-align:center; font-size:15px">'+title+'</h1>' ); }
        
    });

    var table = $('#table').DataTable(

       {"sScrollY": "350px",
       "sScrollX": "400px",} 
       
    );

    
    
    table.columns().every(function () {
        var table = this;
          
                $('input', this.header()).on('keyup change', function () {
                    if (table.search() !== this.value) {
                        table.search(this.value).draw();
                    }
            
         });
        
 });

});


$(document).ready(function () {

    $('#table4 thead th').each(function () {
        var title = $(this).text();  
        if (title!='Acciones'){ 
        $(this).html('<h1 style="width:100%; text-align:center; font-size:15px"><b>'+title+'</b></h1><input type="text"  style="width:100%" placeholder="Buscar..." />' ); }
        if (title=='Acciones'){ 
            $(this).html('<h1 style="width:100%; text-align:center; font-size:15px">'+title+'</h1>' ); }
       
        
    });

    var table = $('#table4').DataTable(

       {"sScrollY": "350px",
       "sScrollX": "400px",} 
       
    );

    table.columns().every(function () {
        var table = this;
          
                $('input', this.header()).on('keyup change', function () {
                    if (table.search() !== this.value) {
                        table.search(this.value).draw();
                    }
            
         });
        
 });

});


$(document).ready(function() {
    $('#table5').DataTable( {
        "searching":   false,
        scrollX: true,
        dom: 'Bfrtip',
        buttons: [{
            extend: 'excel',
            title: 'Orbis Logistics: Reporte Colocación'
        },  {
            extend: 'pdf',
            orientation: 'landscape',
            pageSize: 'A4',
            title: 'Orbis Logistics: Reporte Colocación'
        },{
            extend: 'print',
            title: 'Orbis Logistics: Reporte Colocación'
           
        }]

    } );
} );



$(document).ready(function() {
    $('#tablemodal').DataTable( {
        "paging":   true,
        "lengthMenu": [ [5, 10, 25, 50, -1], [5, 10, 25, 50, "todos"] ],
        'iDisplayLength': 5,
       
    } );
} );