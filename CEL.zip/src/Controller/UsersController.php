<?php
namespace App\Controller;

use App\Controller\AppController;
use Cake\ORM\TableRegistry;

/**
 * Users Controller
 *
 *
 * @method \App\Model\Entity\User[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class UsersController extends AppController
{
    /**
     * Index method
     *
     * @return \Cake\Http\Response|null
     */
    public function logout()
    {
        return $this->redirect($this->Auth->logout());
    }
    
    
     public function login()
    {
        if($this->request->is('post'))
        {
            $user = $this->Auth->identify();
            if($user)
            {
                $this->Auth->setUser($user);
                return $this->redirect($this->Auth->redirectUrl());
            }
            else
            {
                $this->Flash->error('Los datos son invalidos', ['key' => 'auth']);
            }
        }
       
        if ($this->Auth->user())
        {
            return $this->redirect(['controller' => 'Users', 'action' => 'home']);
        }
        
    }
    
    
    
     public function index()
    {

      

        $users =  $this->Users->find()->select(['id', 'first_name', 'email', 'role'])
        ->where(['first_name !=' => 'admin']);

        $this->set('users', $users);
    }



    public function home()
    {
        
        $query = TableRegistry::getTableLocator()->get('Colocacion')->find('all');
        $numberColoc = $query->count();
        $this->set('numberColoc', $numberColoc);

        $query5 = TableRegistry::getTableLocator()->get('General')->find('all')->where(['colocacion'=>'']);
        $numberPo2 = $query5->count();
        $this->set('numberPo2', $numberPo2);

        $query2 = TableRegistry::getTableLocator()->get('General')->find('all');
        $numberPo = $query2->count();
        $this->set('numberPo', $numberPo);

        $query3 = TableRegistry::getTableLocator()->get('Colocacion')->find();
        $sumaFactura = 0;
        foreach ($query3 as $query4)
        {$sumaFactura = ((double)$query4->orbisTotalFactura) + $sumaFactura;}
        $this->set('sumaFactura', $sumaFactura);

       



        $query6 = TableRegistry::getTableLocator()->get('Colocacion')->find('all')->contain(['Estatus'])
        ->where(['Estatus.id' => 6]);;
        $numberDescargada = $query6->count();
        $this->set('numberDescargada', $numberDescargada);

        $query7 = TableRegistry::getTableLocator()->get('Colocacion')->find('all')->contain(['Estatus'])
        ->where(['Estatus.id' => 8]);;
        $numberTransito = $query7->count();
        $this->set('numberTransito',  $numberTransito);

        $query8 = TableRegistry::getTableLocator()->get('Colocacion')->find('all')->contain(['Estatus'])
        ->where(['Estatus.id' => 10]);;
        $numberPlanta = $query8->count();
        $this->set('numberPlanta',  $numberPlanta);

        $query9 = TableRegistry::getTableLocator()->get('Colocacion')->find('all')->contain(['Estatus'])
        ->where(['Estatus.id' => 12]);;
        $numberPatio = $query9->count();
        $this->set('numberPatio',  $numberPatio);


        $query10 = TableRegistry::getTableLocator()->get('Colocacion')->find();
        $sumaPesos = 0;
        foreach ($query10 as $query11)
        {$sumaPesos = ((double)$query11->orbisPeso) + $sumaPesos;}
        $this->set('sumaPesos', $sumaPesos);

        $query12 = TableRegistry::getTableLocator()->get('Colocacion')->find();
        $sumaDolares = 0;
        foreach ($query12 as $query13)
        {$sumaDolares = ((double)$query13->orbisDolares) + $sumaDolares;}
        $this->set('sumaDolares', $sumaDolares);


        $oplinea = TableRegistry::getTableLocator()->get('lineas')->find('list')->select(['name']);
        $this->set('oplinea', $oplinea); 

        if($this->request->is('ajax'))
        {
          
            $linea = $this->request->data['linea'];
            $reslinea = TableRegistry::getTableLocator()->get('Colocacion')->find('all')->contain(['Lineas','Transfers','Estatus'])
            ->where(['Colocacion.cruce !=' => ''])
            ->where(['Lineas.id' => $linea])
            ->where(['Estatus.id !=' => 6]);
            $numberlinea= $reslinea->count();
            header('Content-Type: application/json');
            return $this->response->withType("application/json")->withStringBody(json_encode($numberlinea));
        } 
           
       


    }

    /**
     * View method
     *
     * @param string|null $id User id.
     * @return \Cake\Http\Response|null
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $user = $this->Users->get($id, [
            'contain' => [],
        ]);

        $this->set('user', $user);
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $user = $this->Users->newEntity();
        if ($this->request->is('post')) {
            $user = $this->Users->patchEntity($user, $this->request->getData());
            if ($this->Users->save($user)) {
                $this->Flash->success(__('El Usuario se guardo Correctamente.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('El ususrio no pudo ser guardado.'));
        }
        $this->set(compact('user'));
    }

    /**
     * Edit method
     *
     * @param string|null $id User id.
     * @return \Cake\Http\Response|null Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $user = $this->Users->get($id, [
            'contain' => [],
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $user = $this->Users->patchEntity($user, $this->request->getData());
            if ($this->Users->save($user)) {
                $this->Flash->success(__('El Usuario se guardo Correctamente.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('El ususrio no pudo ser guardado.'));
        }
        $this->set(compact('user'));
    }

    /**
     * Delete method
     *
     * @param string|null $id User id.
     * @return \Cake\Http\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $user = $this->Users->get($id);
        if ($this->Users->delete($user)) {
            $this->Flash->success(__('El Usuario se ha eliminado.'));
        } else {
            $this->Flash->error(__('El Usuario no ha podido eliminarse.'));
        }

        return $this->redirect(['action' => 'index']);
    }

    public function isAuthorized($user)
    {
        if(isset($user['role']) and $user['role'] === 'user')
        {
            //if(in_array($this->request->action, ['home', 'view', 'logout']))
            if(in_array($this->request->getParam('action'), ['home', 'logout']))
            {
                return true;
            }
        }
        return parent::isAuthorized($user);
    }
}
