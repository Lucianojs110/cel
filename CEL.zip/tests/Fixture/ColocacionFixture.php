<?php
namespace App\Test\Fixture;

use Cake\TestSuite\Fixture\TestFixture;

/**
 * ColocacionFixture
 */
class ColocacionFixture extends TestFixture
{
    /**
     * Table name
     *
     * @var string
     */
    public $table = 'colocacion';
    /**
     * Fields
     *
     * @var array
     */
    // @codingStandardsIgnoreStart
    public $fields = [
        'id' => ['type' => 'integer', 'length' => 11, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => '', 'autoIncrement' => true, 'precision' => null],
        'colocacion' => ['type' => 'string', 'length' => 50, 'null' => false, 'default' => null, 'collate' => 'latin1_spanish_ci', 'comment' => '', 'precision' => null, 'fixed' => null],
        'caja' => ['type' => 'string', 'length' => 50, 'null' => false, 'default' => null, 'collate' => 'latin1_spanish_ci', 'comment' => '', 'precision' => null, 'fixed' => null],
        'linea_id' => ['type' => 'integer', 'length' => 11, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => '', 'precision' => null, 'autoIncrement' => null],
        'id_general' => ['type' => 'string', 'length' => 50, 'null' => false, 'default' => null, 'collate' => 'latin1_spanish_ci', 'comment' => '', 'precision' => null, 'fixed' => null],
        'pickup' => ['type' => 'string', 'length' => 50, 'null' => false, 'default' => null, 'collate' => 'latin1_spanish_ci', 'comment' => '', 'precision' => null, 'fixed' => null],
        'cliente' => ['type' => 'string', 'length' => 50, 'null' => false, 'default' => null, 'collate' => 'latin1_spanish_ci', 'comment' => '', 'precision' => null, 'fixed' => null],
        'entrega' => ['type' => 'string', 'length' => 50, 'null' => false, 'default' => null, 'collate' => 'latin1_spanish_ci', 'comment' => '', 'precision' => null, 'fixed' => null],
        'poanexo' => ['type' => 'string', 'length' => 50, 'null' => false, 'default' => null, 'collate' => 'latin1_spanish_ci', 'comment' => '', 'precision' => null, 'fixed' => null],
        'trasbordo' => ['type' => 'string', 'length' => 50, 'null' => false, 'default' => null, 'collate' => 'latin1_spanish_ci', 'comment' => '', 'precision' => null, 'fixed' => null],
        'entregada' => ['type' => 'string', 'length' => 50, 'null' => false, 'default' => null, 'collate' => 'latin1_spanish_ci', 'comment' => '', 'precision' => null, 'fixed' => null],
        'importacion' => ['type' => 'string', 'length' => 50, 'null' => false, 'default' => null, 'collate' => 'latin1_spanish_ci', 'comment' => '', 'precision' => null, 'fixed' => null],
        'cruce' => ['type' => 'string', 'length' => 50, 'null' => false, 'default' => null, 'collate' => 'latin1_spanish_ci', 'comment' => '', 'precision' => null, 'fixed' => null],
        'transfer_id' => ['type' => 'integer', 'length' => 11, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => '', 'precision' => null, 'autoIncrement' => null],
        'estatus_id' => ['type' => 'integer', 'length' => 11, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => '', 'precision' => null, 'autoIncrement' => null],
        'despacho' => ['type' => 'string', 'length' => 50, 'null' => false, 'default' => null, 'collate' => 'latin1_spanish_ci', 'comment' => '', 'precision' => null, 'fixed' => null],
        'descargada' => ['type' => 'string', 'length' => 50, 'null' => false, 'default' => null, 'collate' => 'latin1_spanish_ci', 'comment' => '', 'precision' => null, 'fixed' => null],
        'transRecepcion' => ['type' => 'string', 'length' => 50, 'null' => false, 'default' => null, 'collate' => 'latin1_spanish_ci', 'comment' => '', 'precision' => null, 'fixed' => null],
        'transportista' => ['type' => 'string', 'length' => 50, 'null' => false, 'default' => null, 'collate' => 'latin1_spanish_ci', 'comment' => '', 'precision' => null, 'fixed' => null],
        'transFactura' => ['type' => 'string', 'length' => 50, 'null' => false, 'default' => null, 'collate' => 'latin1_spanish_ci', 'comment' => '', 'precision' => null, 'fixed' => null],
        'transImporte' => ['type' => 'string', 'length' => 50, 'null' => false, 'default' => null, 'collate' => 'latin1_spanish_ci', 'comment' => '', 'precision' => null, 'fixed' => null],
        'transPago' => ['type' => 'string', 'length' => 50, 'null' => false, 'default' => null, 'collate' => 'latin1_spanish_ci', 'comment' => '', 'precision' => null, 'fixed' => null],
        'transCheque' => ['type' => 'string', 'length' => 50, 'null' => false, 'default' => null, 'collate' => 'latin1_spanish_ci', 'comment' => '', 'precision' => null, 'fixed' => null],
        'transferRecepcion' => ['type' => 'string', 'length' => 50, 'null' => false, 'default' => null, 'collate' => 'latin1_spanish_ci', 'comment' => '', 'precision' => null, 'fixed' => null],
        'transfer2' => ['type' => 'string', 'length' => 50, 'null' => false, 'default' => null, 'collate' => 'latin1_spanish_ci', 'comment' => '', 'precision' => null, 'fixed' => null],
        'transferImporte' => ['type' => 'string', 'length' => 50, 'null' => false, 'default' => null, 'collate' => 'latin1_spanish_ci', 'comment' => '', 'precision' => null, 'fixed' => null],
        'transferPago' => ['type' => 'string', 'length' => 50, 'null' => false, 'default' => null, 'collate' => 'latin1_spanish_ci', 'comment' => '', 'precision' => null, 'fixed' => null],
        'transferCheque' => ['type' => 'string', 'length' => 50, 'null' => false, 'default' => null, 'collate' => 'latin1_spanish_ci', 'comment' => '', 'precision' => null, 'fixed' => null],
        'orbisFactura' => ['type' => 'string', 'length' => 50, 'null' => false, 'default' => null, 'collate' => 'latin1_spanish_ci', 'comment' => '', 'precision' => null, 'fixed' => null],
        'orbisCliente' => ['type' => 'string', 'length' => 50, 'null' => false, 'default' => null, 'collate' => 'latin1_spanish_ci', 'comment' => '', 'precision' => null, 'fixed' => null],
        'orbisPeso' => ['type' => 'string', 'length' => 50, 'null' => false, 'default' => null, 'collate' => 'latin1_spanish_ci', 'comment' => '', 'precision' => null, 'fixed' => null],
        'orbisDolares' => ['type' => 'string', 'length' => 50, 'null' => false, 'default' => null, 'collate' => 'latin1_spanish_ci', 'comment' => '', 'precision' => null, 'fixed' => null],
        'orbisTotalFactura' => ['type' => 'string', 'length' => 50, 'null' => false, 'default' => null, 'collate' => 'latin1_spanish_ci', 'comment' => '', 'precision' => null, 'fixed' => null],
        'orbisEnvio' => ['type' => 'string', 'length' => 50, 'null' => false, 'default' => null, 'collate' => 'latin1_spanish_ci', 'comment' => '', 'precision' => null, 'fixed' => null],
        'orbisRelacion' => ['type' => 'string', 'length' => 50, 'null' => false, 'default' => null, 'collate' => 'latin1_spanish_ci', 'comment' => '', 'precision' => null, 'fixed' => null],
        'orbisPago' => ['type' => 'string', 'length' => 50, 'null' => false, 'default' => null, 'collate' => 'latin1_spanish_ci', 'comment' => '', 'precision' => null, 'fixed' => null],
        'orbisCheque' => ['type' => 'string', 'length' => 50, 'null' => false, 'default' => null, 'collate' => 'latin1_spanish_ci', 'comment' => '', 'precision' => null, 'fixed' => null],
        '_indexes' => [
            'linea' => ['type' => 'index', 'columns' => ['linea_id'], 'length' => []],
            'transfer_id' => ['type' => 'index', 'columns' => ['transfer_id'], 'length' => []],
            'estatus_id' => ['type' => 'index', 'columns' => ['estatus_id'], 'length' => []],
        ],
        '_constraints' => [
            'primary' => ['type' => 'primary', 'columns' => ['id'], 'length' => []],
            'colocacion_ibfk_1' => ['type' => 'foreign', 'columns' => ['linea_id'], 'references' => ['lineas', 'id'], 'update' => 'restrict', 'delete' => 'restrict', 'length' => []],
            'colocacion_ibfk_2' => ['type' => 'foreign', 'columns' => ['estatus_id'], 'references' => ['estatus', 'id'], 'update' => 'restrict', 'delete' => 'restrict', 'length' => []],
            'colocacion_ibfk_3' => ['type' => 'foreign', 'columns' => ['transfer_id'], 'references' => ['transfers', 'id'], 'update' => 'restrict', 'delete' => 'restrict', 'length' => []],
        ],
        '_options' => [
            'engine' => 'InnoDB',
            'collation' => 'latin1_spanish_ci'
        ],
    ];
    // @codingStandardsIgnoreEnd
    /**
     * Init method
     *
     * @return void
     */
    public function init()
    {
        $this->records = [
            [
                'id' => 1,
                'colocacion' => 'Lorem ipsum dolor sit amet',
                'caja' => 'Lorem ipsum dolor sit amet',
                'linea_id' => 1,
                'id_general' => 'Lorem ipsum dolor sit amet',
                'pickup' => 'Lorem ipsum dolor sit amet',
                'cliente' => 'Lorem ipsum dolor sit amet',
                'entrega' => 'Lorem ipsum dolor sit amet',
                'poanexo' => 'Lorem ipsum dolor sit amet',
                'trasbordo' => 'Lorem ipsum dolor sit amet',
                'entregada' => 'Lorem ipsum dolor sit amet',
                'importacion' => 'Lorem ipsum dolor sit amet',
                'cruce' => 'Lorem ipsum dolor sit amet',
                'transfer_id' => 1,
                'estatus_id' => 1,
                'despacho' => 'Lorem ipsum dolor sit amet',
                'descargada' => 'Lorem ipsum dolor sit amet',
                'transRecepcion' => 'Lorem ipsum dolor sit amet',
                'transportista' => 'Lorem ipsum dolor sit amet',
                'transFactura' => 'Lorem ipsum dolor sit amet',
                'transImporte' => 'Lorem ipsum dolor sit amet',
                'transPago' => 'Lorem ipsum dolor sit amet',
                'transCheque' => 'Lorem ipsum dolor sit amet',
                'transferRecepcion' => 'Lorem ipsum dolor sit amet',
                'transfer2' => 'Lorem ipsum dolor sit amet',
                'transferImporte' => 'Lorem ipsum dolor sit amet',
                'transferPago' => 'Lorem ipsum dolor sit amet',
                'transferCheque' => 'Lorem ipsum dolor sit amet',
                'orbisFactura' => 'Lorem ipsum dolor sit amet',
                'orbisCliente' => 'Lorem ipsum dolor sit amet',
                'orbisPeso' => 'Lorem ipsum dolor sit amet',
                'orbisDolares' => 'Lorem ipsum dolor sit amet',
                'orbisTotalFactura' => 'Lorem ipsum dolor sit amet',
                'orbisEnvio' => 'Lorem ipsum dolor sit amet',
                'orbisRelacion' => 'Lorem ipsum dolor sit amet',
                'orbisPago' => 'Lorem ipsum dolor sit amet',
                'orbisCheque' => 'Lorem ipsum dolor sit amet',
            ],
        ];
        parent::init();
    }
}
